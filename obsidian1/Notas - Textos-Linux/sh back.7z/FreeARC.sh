#!/bin/bash

sudo wine /home/ximena/.wine/drive_c/"Program Files (x86)"/FreeArc/bin/FreeArc.exe

echo "Se Ejecuto FreeARC"

#chmod 777 luzTeclado.sh
#Ejecutar con ./luzTeclado.sh
# sudo apt install x11-xserver-utils

#12:54 p. m. 03/09/2022
