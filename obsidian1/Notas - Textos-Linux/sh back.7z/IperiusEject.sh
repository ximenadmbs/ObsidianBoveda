#!/bin/bash

sudo wine /home/ximena/.wine/drive_c/"Program Files (x86)"/"Iperius Backup"/Iperius.exe

echo "Se Ejecuto Iperius Backup"

#chmod 777 luzTeclado.sh
#Ejecutar con ./luzTeclado.sh
# sudo apt install x11-xserver-utils

#12:54 p. m. 03/09/2022
